<?php
session_start();
$username=$_SESSION['username'];
//echo $username;
if(!isset($_SESSION['username']))
{
	header('location:s_remove.php');
}

?>

<HTML>

<center>Your eWallet account has been deleted!!
</center>

</HTML>