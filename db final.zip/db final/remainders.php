<body>
<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<body>
<form> 
<form>
<input type="button" value="Logout" onClick="window.location.href='logout.php'"></form>
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Reminders" onClick="window.location.href='remainders1.php?username=$username'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>
<?php
session_start();
$username=$_SESSION['username'];

if(isset($_REQUEST['attempt']))
{
$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
mysql_select_db($username);
$event = mysql_real_escape_string($_POST['event']);
$dd = mysql_real_escape_string($_POST['$day']);
$mm = mysql_real_escape_string($_POST['$month']);
$yy = mysql_real_escape_string($_POST['$year']);

$query = mysql_query("INSERT INTO reminders(event,date) VALUES                                        ('$event','$yy/$mm/$dd')" )or die(mysql_error());
}
?>
 
<TABLE Border = "1"  Bgcolor="#C1DAEA"  Width="550"  Height="200" CellPadding = "10"  CellSpacing = "5" Align="center">
<CAPTION><font size="5" face="verdana"><B>ADD A REMAINDER</B></font></CAPTION>
<Form name="form1" Method="POST" Action="remainders.php?attempt">
<tr>
<tr><td COLSPAN = 1 >
Event  <INPUT  TYPE = "text"  name="event">
			<br></td>
<td COLSPAN = 1>
Date <select name="$day" width=30>
<?php
$i = 1;
while($i <= 31)
{
?>			<OPTION Value= <?php echo $i; ?> >
           <?php echo $i; ?></OPTION>
<?php 
$i = $i +1;
} ?>           
</select>
<?php echo $day; ?>
<select name="$month" width=30>
<?php
$i = 1;
while($i < 13)
{
	switch($i)
	{
		case '1': $mon='Jan'; break;
		case '2': $mon='Feb'; break;
		case '3': $mon='Mar'; break;
		case '4': $mon='Apr'; break;
		case '5': $mon='May'; break;
		case '6': $mon='Jun'; break;
		case '7': $mon='Jul'; break;
		case '8': $mon='Aug'; break;
		case '9': $mon='Sep'; break;
		case '10': $mon='Oct'; break;
		case '11': $mon='Nov'; break;
		case '12': $mon='Dec'; break;
	}
?>			<OPTION Value=<?php echo $i; ?>>
           <?php echo $mon; ?></OPTION>
<?php
$i =$i +1;
}
?> 
</select>
<select name="$year" width=30>
<?php
$i=2010;
while($i< 2021)
{?> 
      
           <OPTION Value=<?php echo $i; ?>>
           <?php echo $i; ?></OPTION>
           
<?php 
$i = $i +1;
} ?>           
</select>      
</td></tr>
<tr>
<td COLSPAN = 1>
<INPUT TYPE = "SUBMIT" VALUE ="Add" >
<INPUT TYPE = "RESET" VALUE ="Clear">
</td>
<td colspan="1">
<input type="button" value="Click here to view" onClick="window.location.href='remainders1.php?username=$username'"></td></tr>
</Form>
</table>
</body>