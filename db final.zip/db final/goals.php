<?php
session_start();
$username=$_SESSION['username'];
//echo $username;
if(isset($_REQUEST['attempt']))
{
	$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db($username);
	
	$amount = mysql_real_escape_string($_POST['amount']);
	mysql_select_db('project',$link);
	$details = mysql_real_escape_string($_POST['details']);
	
	$query1 = mysql_query("SELECT categoryid FROM categories WHERE details = '$details'") or die(mysql_error());
	
	$result = mysql_fetch_assoc($query1);
	$catid = $result['categoryid'];
	//echo $catid;
	
	mysql_select_db($username,$link);
	
	$query4 = mysql_query("DELETE FROM budget WHERE categoryid = '$catid'") or die(mysql_error());
	
	$query = mysql_query("INSERT INTO budget(categoryid,max_amt)VALUES('$catid','$amount')" )or die(mysql_error());
	
	$query2 = mysql_query("SELECT SUM(amount) FROM transactions WHERE categoryid = '$catid'") or die(mysql_error());
	$res = mysql_num_rows($query2);
	if($res <= 0)
	{
	}
	else
	{
	$result = mysql_fetch_assoc($query2);
	$spent = $result['SUM(amount)'];
	
	$query3 = mysql_query("UPDATE budget SET spent_amt='$spent' WHERE categoryid = '$catid'") or die(mysql_error());
	}
}
?>
<body>
<form> 
<form>
<input type="button" value="Logout" onClick="window.location.href='logout.php'"></form>
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Reminders" onClick="window.location.href='remainders1.php?username=$username'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>

<TABLE Border = "1"  Bgcolor="#FFFFD5"  Width="550"  Height="100" CellPadding = "10"  CellSpacing = "5" Align="center">
<CAPTION><font size="5" face="verdana"><B>Set Your Goals</B></font></CAPTION>
<Form name="form1" Method="POST" Action="goals.php?attempt">
<tr>
<td COLSPAN = 1>
Category<select name="details" width=30>
           <OPTION Value="Mobiles & Accessories">
           Mobiles & Accessories</OPTION>
	       <OPTION Value="Computers" >
           Computers</OPTION>
           <OPTION Value="Books" >
           Books</OPTION>
           <OPTION Value="Cameras" >
           Cameras</OPTION>
           <OPTION Value="Personal &Health care" >           Personal & Health care</OPTION>
	       <OPTION Value="Home & Kitchen" >
           Home & Kitchen</OPTION>
	       <OPTION Value="Movies" >
           Movies</OPTION>
	       <OPTION Value="Stationary" >
           Stationary</OPTION>
           <OPTION Value="Credit card" >
           Credit card</OPTION>
           <OPTION Value="ATM" >
           ATM</OPTION>
           <OPTION Value="Investments" >
           Investments</OPTION>
           <OPTION Value="Others" >
           Others</OPTION>
           </SELECT>
           </td> 
<td COLSPAN = 1 >
Amount<INPUT  TYPE = "text"  name="amount">
			<br></td></tr>

         
<tr>
<td>
<INPUT TYPE = "SUBMIT" VALUE ="Set" >
<input type="button" value="Click here to view" onClick="window.location.href='goals1.php?username=$username'"></td></tr>
</Form>
</table>
</body>
