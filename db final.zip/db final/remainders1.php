<body>
<form> 
<form>
<input type="button" value="Logout" onClick="window.location.href='logout.php'"></form>
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Reminders" onClick="window.location.href='remainders1.php?username=$username'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>

 <?php error_reporting (E_ALL ^ E_NOTICE); ?>
<h3 align="center">REMINDER DETAILS</h3>
</head>

<?PHP
session_start();
$username=$_SESSION['username'];
//$username='pqr';?>
<center><form>
<input type="button" value="Click here to add remainders" onClick="window.location.href='remainders.php?username=$username'">
</font>
</Form></center>

<?php
	$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
	
	mysql_select_db($username);
?>
<table border="3" align="center" cellpadding="7" cellspacing="1" bgcolor="#FFFFFF" bordercolor="#336699">
<tr>

<?php 
 $date =time ();
 $day = date('d', $date) ; 
 $month = date('m', $date) ; 
$year = date('Y', $date) ;
 $week = date('W',$date);
	$mon = $month;
$i=1;
while($month <= 12)
{
 $first_day = mktime(0,0,0,$month, 1, $year) ; 
 $title = date('F', $first_day) ; 

 $day_of_week = date('D', $first_day) ; 
 
 switch($day_of_week)
 { 
	case "Sun": $blank = 0; break; 
	case "Mon": $blank = 1; break; 
	case "Tue": $blank = 2; break; 
	case "Wed": $blank = 3; break; 
	case "Thu": $blank = 4; break; 
	case "Fri": $blank = 5; break; 
	case "Sat": $blank = 6; break; 
 }
 $days_in_month = cal_days_in_month(0, $month, $year) ; 
 if($i % 2 == 1)
 {
	 echo "</tr><tr>";
 }
 echo "<td>";
 echo "<table border=1 width=600 align=center height=200 bordercolor=#FFFFFF bgcolor=#C1DAEA>";

 echo "<tr><th colspan=7> $title $year </th></tr>";

 echo "<tr><td width=60>Sun</td>
 	<td width=60>Mon</td>
	<td width=60>Tue</td>
	<td width=60>Wed</td>
	<td width=60>Thu</td>
	<td width=60>Fri</td>
	<td width=60>Sat</td></tr>";
 $day_count = 1;
 echo "<tr>";
 while ( $blank > 0 ) 
{ 
	echo "<td></td>"; 
	$blank = $blank-1; 
	$day_count++;
}
 $day_num = 1;
 while ( $day_num <= $days_in_month ) 
 { 
	echo "<td>  $day_num "; 
 	$query = mysql_query("SELECT event FROM reminders WHERE date='$year/$month/$day_num'");
	while($res= mysql_fetch_assoc($query))
	{
	$event = $res['event'];
	echo "<br>$event "; 
	}
	echo "</td>";
	$day_num++; 
	$day_count++;
    if ($day_count > 7)
	{
		echo "</tr><tr>";
		$day_count = 1;
	}
 } 
 while ( $day_count >1 && $day_count <=7 ) 
 { 
	echo "<td> </td>"; 
	$day_count++; 
 } 
 echo "</tr></table>"; 
	$month= $month+1;

	$i =$i+1;
echo "</td>";
}


$month = 1;
$year = $year+1;
while($month <= $mon)
{
 $first_day = mktime(0,0,0,$month, 1, $year) ; 
$title = date('F', $first_day) ; 
$day_of_week = date('D', $first_day) ; 
 switch($day_of_week)
 { 
 case "Sun": $blank = 0; break; 
 case "Mon": $blank = 1; break; 
 case "Tue": $blank = 2; break; 
 case "Wed": $blank = 3; break; 
 case "Thu": $blank = 4; break; 
 case "Fri": $blank = 5; break; 
 case "Sat": $blank = 6; break; 
 }
 $days_in_month = cal_days_in_month(0, $month, $year) ; 
 if($i % 2 == 1)
 {
	 echo "</tr><tr>";
 }
 echo "<td>";
 echo "<table border=1 width=600 align=center height=200 bordercolor=#FFFFFF bgcolor=#C1DAEA>";

 echo "<tr><th colspan=7> $title $year </th></tr>";

 echo "<tr><td width=60>Sun</td>
 <td width=60>Mon</td>
 <td width=60>Tue</td>
 <td width=60>Wed</td>
 <td width=60>Thu</td>
 <td width=60>Fri</td>
 <td width=60>Sat</td></tr>";
 $day_count = 1;
 echo "<tr>";
 while ( $blank > 0 ) 
 { 
 echo "<td></td>"; 
 $blank = $blank-1; 
 $day_count++;
 } 
 $day_num = 1;
 while ( $day_num <= $days_in_month ) 
 { 
 	echo "<td> $day_num "; 
 	$query = mysql_query("SELECT event FROM reminders WHERE date='$year/$month/$day_num'");
	while($res= mysql_fetch_assoc($query))
	{
	$event = $res['event'];
	echo "<br>$event";
	}
	echo "</td>";
	$day_num++; 
 	$day_count++;
 	if ($day_count > 7)
 	{
		echo "</tr><tr>";
		$day_count = 1;
 	}
 } 
 while ( $day_count >1 && $day_count <=7 ) 
 { 
 	echo "<td> </td>"; 
	$day_count++; 
 } 
 echo "</tr></table>"; 
 $month= $month+1;
$i =$i+1;
echo "</td>";
} 
echo "</table>"; 
 ?>
 