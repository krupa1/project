<?PHP

session_start();
session_destroy();

?>
<center>You are logged out!!</center>