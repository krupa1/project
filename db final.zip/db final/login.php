<?php

if(isset($_REQUEST['attempt']))
{

$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
mysql_select_db('project');
$username=mysql_real_escape_string($_POST['username']);
$password=sha1(mysql_real_escape_string($_POST['password']));

$query = mysql_query("
	SELECT username FROM user_details
	WHERE username = '$username'
	AND password = '$password'
	") or die(mysql_error());

$total = mysql_num_rows($query);

	if($total > 0)
	{
		session_start();
		$_SESSION['username']=$username;
		header('location:dashboard.php?username=$username');
	}
	else
	{ 
 		echo "Enter proper username and password";
	}
}

?>
<html>


<TABLE Border = "1"  Bgcolor="LIGHTBLUE"  Width="350"  Height="100" CellPadding = "10"  CellSpacing = "2" Align="CENTER">
<CAPTION><font size="4" face="Tahoma, Geneva, sans-serif"><B>Login</B></font></CAPTION>
<form method="post" action="login.php?attempt">
<tr>
<td colspan="1">
Username <input type="text" name="username"/><br/>
Password <input type="password" name="password">
</td></tr>
<tr>
<td colspan="0">
<center><input type="submit"  value="Login"/></center></td>
</tr>

</form></TABLE>
</html>