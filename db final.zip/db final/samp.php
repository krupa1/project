<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<?php
$username = 'abc';

$link = mysql_connect('localhost','root','mysql') or die('cant connect to database');mysql_select_db($username,$link);
$query3 = mysql_query("SELECT * FROM account_details") or die(mysql_error());
$num1 = mysql_num_rows($query3);
//echo $num1;
$i = 0;
while($i < $num1) 
 	{  
		
		$row = mysql_fetch_assoc($query3);
		$id = $row['id'];
		$fin ='SBM';
		$acc_no = $row['acc_no'];
		$acc_type = $row['acc_type'];
		$details = $row['details'];
		$trans_type = $row['trans_type'];
		$amt = $row['amount'];
		$balance = $row['balance'];
		$date = $row['date'];
		$time = $row['time'];
		$cat = $row['category'];
	Print "<tr>"; 
 	
	//echo $catid;
	//mysql_select_db('project',$link);
	//$query = mysql_query("SELECT details FROM categories WHERE categoryid= '$catid'") or die(mysql_error());
	//$result = mysql_fetch_assoc($query);
	
	//echo $res;
	//Print "<td bgcolor=#FFFFFF>".$res . "</td>"; 
 	
	//mysql_select_db($username,$link);
	//$accno=$info['Account_no'];
	//echo $accno;
	Print "<td bgcolor=#FFFFFF align=center>".$acc_no." </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$acc_type . " </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$details . " </td>"; 
	Print "<td bgcolor=#FFFFFF align=center>".$trans_type . " </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$amt . " </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$balance . " </td>";
	
	
	Print "<td bgcolor=#FFFFFF align=center>".$date . " </td>";
	Print "<td bgcolor=#FFFFFF align=center>".$time . " </td>";
	//$rem = $info['max_amt']-$info['spent_amt'];
	//Print "<td bgcolor=#FFFFFF>".$rem . " </td></tr>";
	
	if($cat == 0)
	{
	 include 'addcat.php'; 
	}
	$i =$i + 1;
	} 


?>
