<?php
session_start();
$username=$_SESSION['username'];
if(isset($_REQUEST['attempt']))
{
	//$username1 = 'efgh';
	$link = mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db('project');

	$query1 = mysql_query("DELETE FROM TABLE WHERE username=$username") or die(mysql_error());
	mysql_select_db($username,$link);
	$query2 = mysql_query("DROP DATABASE $username") or die(mysql_error());
}
?>

<TABLE Border = "1"  Bgcolor="LIGHTBLUE"  Width="400"  Height="100" CellPadding = "10"  CellSpacing = "2" Align="CENTER">
<CAPTION><font size="3" face="Tahoma, Geneva, sans-serif"><B>Remove account</B></font></CAPTION>
<form method="post" action="s_remove.php?attempt">
<tr><td>Are you sure that you want to remove your account permanently?</td></tr>
<tr><td>
<input type="submit"  value="Yes"/>
<input type="button" value="No" onClick="window.location.href='settings.php?username=$username1'">
</td>
</tr>
</form>
</TABLE>