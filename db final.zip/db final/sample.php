<table>
<tr>
<td>

<table>
<tr>
<input type="button" value="Click here to add transactions" onClick="window.location.href='trans1.php?username=$username'">
</tr><tr>
<input type="button" value="Click here to add transactions" onClick="window.location.href='trans1.php?username=$username'">
</tr>
</table>
</td>
<td>
<table>
<tr>
<Form name="form1" Method="POST" Action="accounts1.php?attempt">
<tr>
<td COLSPAN = 1 >
Fin_inst_name <SELECT  name="fin_inst_name" >
	 <OPTION  Value="SBM" >SBM</OPTION>
	 </SELECT>
          <br></td>
<td COLSPAN = 1 >
Account No<INPUT  TYPE = "text"  name="Account_no">
	<br></td>
<tr><td COLSPAN = 1>
username <INPUT  TYPE = "text" name= "username" >
         	<br>
password <INPUT  TYPE = "text" name= "password" >
         	<br></td>           
 <td>   
<INPUT TYPE ="SUBMIT" VALUE ="Set" >
<input type="button" value="Click here" onClick="window.location.href='accounts.php?username=$username'"></tr>
</Form>
</tr>
</table>

</td>
</tr>
</table>