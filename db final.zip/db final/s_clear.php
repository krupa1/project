<?php
session_start();
$username=$_SESSION['username'];
if(isset($_REQUEST['attempt']))
{
	$link = mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db($username);

	$query1 = mysql_query("TRUNCATE TABLE accounts") or die(mysql_error());
	$query2 = mysql_query("TRUNCATE TABLE account_details") or die(mysql_error());
	$query3 = mysql_query("TRUNCATE TABLE transactions") or die(mysql_error());
	$query4 = mysql_query("TRUNCATE TABLE budget") or die(mysql_error());
	$query5 = mysql_query("TRUNCATE TABLE alerts") or die(mysql_error());
	
		session_start();
		$_SESSION['username']=$username;
		header('location:edit5.php?username=$username');
}
?>
<TABLE Border = "1"  Bgcolor="LIGHTBLUE"  Width="400"  Height="100" CellPadding = "10"  CellSpacing = "2" Align="CENTER">
<CAPTION><font size="3" face="Tahoma, Geneva, sans-serif"><B>Clear All Data</B></font></CAPTION>
<form method="post" action="s_clear.php?attempt">
<tr><td>Are you sure that you want to delete all data?</td></tr>
<tr><td>Clicking 'Yes' <br>
1. will delete all your accounts,  budget, transaction details and other data which cannot be recovered back<br>
2. will not remove your eWallet account
</td></tr>
<tr><td>Clicking 'Cancel' will redirect you to the previous page without deleting any data
</td></tr>
<tr><td>
<input type="submit"  value="Yes"/>
<input type="button" value="Cancel" onClick="window.location.href='settings.php?username=$username1'">
</td>
</tr>
</form>
</TABLE>