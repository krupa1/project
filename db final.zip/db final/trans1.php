<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<?php
session_start();
$username=$_SESSION['username'];
//echo $username;
if(isset($_REQUEST['attempt']))
{
	$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db($username);
	
	$type = mysql_real_escape_string($_POST['type']);
	$amount = mysql_real_escape_string($_POST['amount']);
	$dd = mysql_real_escape_string($_POST['$day']);
	$mm = mysql_real_escape_string($_POST['$month']);
	$yy = mysql_real_escape_string($_POST['$year']);
	$desciption = mysql_real_escape_string($_POST['description']);
	
	$details = mysql_real_escape_string($_POST['details']);
	
	$query1 = mysql_query("SELECT categoryid FROM categories WHERE details = '$details'") or die(mysql_error());
	
	$result = mysql_fetch_assoc($query1);
	$catid = $result['categoryid'];
	//echo $catid;
	
	//mysql_select_db($username,$link);
	
	$query = mysql_query("INSERT INTO transactions(type,categoryid,amount,date,description)  VALUES                                           ('$type','$catid','$amount','$yy/$mm/$dd','$desciption')" )or die(mysql_error());
}

?>
<body>
<form> 
<form>
<input type="button" value="Logout" onClick="window.location.href='logout.php'"></form>
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Reminders" onClick="window.location.href='remainders1.php?username=$username'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>
 
 
<TABLE Border = "1"  Bgcolor="#F5D6F5"  Width="550"  Height="200" CellPadding = "10"  CellSpacing = "5" Align="center">
<CAPTION><font size="5" face="verdana"><B>ADD A DESCRIPTION</B></font></CAPTION>
<Form name="form1" Method="POST" Action="trans1.php?attempt">
<tr>
<td COLSPAN = 1 >
Type <SELECT  name="type" >
	 <OPTION  Value="Expense" >Expense</OPTION>
	 <OPTION Value="Income" >Income</OPTION></SELECT>
          <br></td>
<td COLSPAN = 1>
Category<select name="details" width=30>
           <OPTION Value="Mobiles & Accessories">
           Mobiles & Accessories</OPTION>
	       <OPTION Value="Computers" >
           Computers</OPTION>
           <OPTION Value="Books" >
           Books</OPTION>
           <OPTION Value="Cameras" >
           Cameras</OPTION>
           <OPTION Value="Personal & Health care" >           Personal & Health care</OPTION>
	       <OPTION Value="Home & Kitchen" >
           Home & Kitchen</OPTION>
	       <OPTION Value="Movies" >
           Movies</OPTION>
	       <OPTION Value="Stationary" >
           Stationary</OPTION>
           <OPTION Value="Credit card" >
           Credit card</OPTION>
           <OPTION Value="ATM" >
           ATM</OPTION>
           <OPTION Value="Investments" >
           Investments</OPTION>
           <OPTION Value="Others" >
           Others</OPTION>
           </SELECT>
           <br></td></tr>          
<tr><td COLSPAN = 1 >
Amount<INPUT  TYPE = "text"  name="amount">
			<br></td>
<td COLSPAN = 1>
Date <select name="$day" width=30>
<?php
$i = 1;
while($i <= 31)
{
?>			<OPTION Value= <?php echo $i; ?> >
           <?php echo $i; ?></OPTION>
<?php 
$i = $i +1;
} ?>           
</select>
<?php echo $day; ?>
<select name="$month" width=30>
<?php
$i = 1;
while($i < 13)
{
	switch($i)
	{
		case '1': $mon='Jan'; break;
		case '2': $mon='Feb'; break;
		case '3': $mon='Mar'; break;
		case '4': $mon='Apr'; break;
		case '5': $mon='May'; break;
		case '6': $mon='Jun'; break;
		case '7': $mon='Jul'; break;
		case '8': $mon='Aug'; break;
		case '9': $mon='Sep'; break;
		case '10': $mon='Oct'; break;
		case '11': $mon='Nov'; break;
		case '12': $mon='Dec'; break;
	}
?>			<OPTION Value=<?php echo $i; ?>>
           <?php echo $mon; ?></OPTION>
<?php
$i =$i +1;
}
?> 
</select>
<select name="$year" width=30>
<?php
$i=2010;
while($i< 2021)
{?> 
      
           <OPTION Value=<?php echo $i; ?>>
           <?php echo $i; ?></OPTION>
           
<?php 
$i = $i +1;
} ?>           
</select>      
</td></tr>
<tr><td COLSPAN = 1 >
Description<INPUT  TYPE = "TEXT" name="description" value="this is optional">
            <br></td>
<td COLSPAN = 1>
<INPUT TYPE = "SUBMIT" VALUE ="Add" >
<INPUT TYPE = "RESET" VALUE ="Clear">
<input type="button" value="Click here to view" onClick="window.location.href='trans.php?username=$username'"></td></tr>
</Form>
</table>
</body>