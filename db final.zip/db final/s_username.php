<?php
session_start();
$username1=$_SESSION['username'];
if(isset($_REQUEST['attempt']))
{
	//$username1 = 'efgh';
	$link = mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db('project');

	$username = mysql_real_escape_string($_POST['username']);
	
	//echo $username;
	$query = mysql_query("
	SELECT username FROM user_details
	WHERE username = '$username'
	") or die(mysql_error());

	$total = mysql_num_rows($query);

	if($total > 0)
	{
		echo "username already exists!! try someother username";	
	}
	else
	{ 
 		
	$query1 = mysql_query("
		UPDATE user_details SET username = '$username' WHERE username = '$username1'
		")or die(mysql_error());
	
	mysql_select_db($username1);	
 
	$result=mysql_query("show tables");
 
	$table_names=array();
	while($row=mysql_fetch_array($result)){
		$table_names[]=$row[0];
	}
 
	mysql_query("create database $username");
	mysql_select_db($username);
 
 
	for($i=0;$i<count($table_names);$i++){
		//mysql_query("create table ".$table_names[$i]." select * from $username1.".$table_names[$i]);
	
	//mysql_query("create table ". $table_names[$i] . " like " . $username1 . "." . $table_names[$i]." select * from $username1.".$table_names[$i]);
	
	$query7 = mysql_query("CREATE TABLE `$table_names[$i]` LIKE `$username1`.`$table_names[$i]`") or die(mysql_error());
	
	$query9 = mysql_query("INSERT $table_names[$i] SELECT * FROM $username1.$table_names[$i]") or die(mysql_error());
	
	}
 	
	mysql_query("ALTER TABLE transactions ADD FOREIGN KEY (categoryid) REFERENCES categories(categoryid)");
	
	mysql_query("ALTER TABLE budget ADD FOREIGN KEY (categoryid) REFERENCES categories(categoryid)");
	
	mysql_query("ALTER TABLE alerts ADD FOREIGN KEY (catid) REFERENCES categories(categoryid)");
	
	mysql_query("DROP DATABASE $username1") or die(mysql_error());
	
	//echo count($table_names)." tables successfully copied!";
		
		session_start();
		$_SESSION['username']=$username;
		header('location:edit1.php?username=$username');
	}
}	
?>

<TABLE Border = "1"  Bgcolor="LIGHTBLUE"  Width="350"  Height="100" CellPadding = "10"  CellSpacing = "2" Align="CENTER">
<CAPTION><font size="3" face="Tahoma, Geneva, sans-serif"><B>Enter new username</B></font></CAPTION>
<form method="post" action="s_username.php?attempt">
<tr>
<td colspan="0">
New username <input type="text" name="username"/>
<br><br>
</td></tr>

<tr>
<td colspan="0" align="center">
<input type="submit"  value="Change"/>
<input type="button" value="Cancel" onClick="window.location.href='settings.php?username=$username1'"></td></tr>
</form></TABLE>