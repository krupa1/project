<?php
?>
<body>
<form> 
<form>
<input type="button" value="Logout" onClick="window.location.href='logout.php'"></form>
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Reminders" onClick="window.location.href='remainders1.php?username=$username'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>
<?php
session_start();
$username=$_SESSION['username'];
$link = mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db('project');
	
	$query = mysql_query("SELECT * FROM user_details WHERE username='$username'") or die(mysql_error());
	
	$result = mysql_fetch_assoc($query);
?>
<TABLE Border = "1"  Bgcolor="#F8DCDF"  Width="550"  Height="200" CellPadding = "10"  CellSpacing = "10" Align="center" style="font-size: 18px">
<CAPTION><font size="4" face="verdana"><B>EDIT YOUR DETAILS</B></font></CAPTION><br>
<font size="4" color="#660000">
<Form name="form1" Method="POST" Action="settings.php?attempt">
<tr>
<td COLSPAN = 1 bgcolor="#FFFFFF">
<font color="#660000" face="Verdana, Geneva, sans-serif">Username:  </font><?php echo $result['username']; ?><div align="right">
<input type="button" align="right" value="Edit" onClick="window.location.href='s_username.php?username=$username'">
</div></td>
<td COLSPAN = 1 bgcolor="#FFFFFF">
<font color="#660000" face="Verdana, Geneva, sans-serif">Password </font><div align="right"><input type="button" align="right" value="Edit" onClick="window.location.href='s_password.php?username=$username'">
</div></td></tr>          


<tr><td COLSPAN = 1 bgcolor="#FFFFFF">
<font color="#660000" face="Verdana, Geneva, sans-serif">Email id: </font><br><?php echo $result['email_id']; ?><div align="right"><input type="button" align="right" value="Edit" onClick="window.location.href='s_email.php?username=$username'"></div>
</td>

<td COLSPAN = 1 bgcolor="#FFFFFF">
<font color="#660000" face="Verdana, Geneva, sans-serif">Mobile: </font><br><?php echo $result['mobile']; ?><div align="right"><input type="button" align="right" value="Edit" onClick="window.location.href='s_mobile.php?username=$username'">
</div></td></tr>

<tr><td COLSPAN = 1 bgcolor="#FFFFFF" >
<font color="#660000" face="Verdana, Geneva, sans-serif">Clear all transaction details </font><div align="right"><input type="button" align="right" value="Click here" onClick="window.location.href='s_clear.php?username=$username'">
</div></td>

<td COLSPAN = 1 bgcolor="#FFFFFF">
<font color="#660000" face="Verdana, Geneva, sans-serif">Remove account </font><div align="right"><input type="button" align="right" value="Remove" onClick="window.location.href='s_remove.php?username=$username'">
</div></td>
</tr>

</Form>
</font>
</table>

</body>