<?php error_reporting (E_ALL ^ E_NOTICE); ?>

<?php
if(isset($_REQUEST['attempt']))
{
	$link = mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db('project');
	
	$query1 = mysql_query("SELECT categoryid FROM categories WHERE details = '$details'") or die(mysql_error());
	echo $details;
	$result = mysql_fetch_assoc($query1);
	$catid = $result['categoryid'];
	echo $catid;
	
}
?>

<form method="post" action="addcat.php?attempt">
category <INPUT type="text" name="$details">
<INPUT TYPE = "SUBMIT" VALUE ="Add" >
</form>
           