<?php
session_start();
$username=$_SESSION['username'];
//echo $username;
if(!isset($_SESSION['username']))
{
	header('location:s_emailid.php');
}

?>

<HTML>

<center>Email id changed!!
<form><input type="button" value="Click here to proceed" onClick="window.location.href='settings.php?username=$username'"></form></center>

</HTML>