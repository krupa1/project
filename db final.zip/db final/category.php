<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<body>
<form> 
<form>
<input type="button" value="Logout" onClick="window.location.href='logout.php'"></form>
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Reminders" onClick="window.location.href='remainders1.php?username=$username'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>
</tr>
<tr>
 <head>
            
<h3 align="center"> PERSONAL TRANSACTION DETAILS</h3>
</head>
</tr>
<?php
session_start();
$username=$_SESSION['username'];
//echo $username;

$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db($username);


//$sql="SELECT * FROM transactions ORDER BY date DESC";
// OREDER BY id DESC is order result by descending 
//$result = mysql_query($sql);
?>
<dd><dd><dd><dd><dd><dd><dd>
<input type="button" value="Monthly View" onClick="window.location.href='monthly.php?username=$username'">
<input type="button" value="Yearly View" onClick="window.location.href='yearly.php?username=$username'">
<input type="button" value="Click here to add transactions" onClick="window.location.href='trans1.php?username=$username'">
<br/>
</br>





<?php
	$query1 = mysql_query("SELECT * FROM categories");
	$rows = mysql_num_rows($query1);
	//echo $rows; 
	$i=1;
	?>
   
<?php	while($i <= $rows)
	{
		$query2=mysql_query("SELECT details FROM categories WHERE categoryid='$i'") or die(mysql_error());
			
		$res = mysql_fetch_assoc($query2);
		$cat = $res['details'];
		$query3 = mysql_query("SELECT * FROM transactions WHERE categoryid='$i'") or die(mysql_error());
		
?>
	
<?php	
	if(mysql_num_rows($query3) > 0)
	{   ?>
<table width="60%" border="0" align="center" cellpadding="7" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Type</strong></td>
<td width="20%" align="center" bgcolor="#F5D6F5"><strong>Amount</strong></td>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Date</strong></td>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Description</strong></td>
</tr>
<br>
<head>
<h4 align="left"><?php echo $cat?></h4>
</head>
	<?php	//echo $cat;
		//echo mysql_num_rows($query3);
	while($result = mysql_fetch_assoc($query3))
		{
	?>
	
<tr>
<td align="center" bgcolor="#FFFFFF"><?php echo $result['type']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $result['amount']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $result['date']; ?></td>

<td align="center" bgcolor="#FFFFFF"><?php echo $result['description']; ?></td>
</tr>
<?php
		}
	}
		$i = $i +1;
 	?>
	</table>
	<?php }
?>
