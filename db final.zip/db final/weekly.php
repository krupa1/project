<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<form> 
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr><td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Dashboard" onClick="window.location.href='dashboard1.php'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>
</tr>
<tr>
 <head>
            
<h3 align="center"> PERSONAL TRANSACTION DETAILS</h3>
</head>
</tr>
<?php
//session_start();
//$username=$_SESSION['username'];
//echo $username;

$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db('abc');


//$sql="SELECT * FROM transactions ORDER BY date DESC";
// OREDER BY id DESC is order result by descending 
//$result = mysql_query($sql);
?>
<dd><dd><dd><dd><dd><dd><dd>
<input type="button" value="Category View" onClick="window.location.href='category.php?username=$username'">
<input type="button" value="Monthly View" onClick="window.location.href='monthly.php?username=$username'">
<input type="button" value="Weekly View" onClick="window.location.href='trans1.php?username=$username'">

<input type="button" value="Click here to add transactions" onClick="window.location.href='trans1.php?username=$username'">
<br/>
</br>
<?php
$date = time();
$w = date('W',$date);
echo $w;

$date = '2012/05/02'; 
$week = (int)date('W', $date); 
echo "Weeknummer: ".$week; 
?>
