<html>
<p style="color:olive;font-size:40px;">FEATURES</p>

 <body>
       <h2>Consolidation of accounts at one place</h2>
       <li> Connects to your account..all in one place</li>
       <li>View your bank accounts,investments,transactions</li>
       <h2>Managing the expenditure</h2>
       <li>View your  categorywise expenditure</li>
       <li>Track your spend over time</li>
       <li>know how much you have left with after expenditure and where can u save</li>
       <h2>Meet your budget goal</h2>
       <li>Compare the actual expenses with budgeted expenses</li>
       <li>Get sms alerts & emails to stay within budget</li>
       <h2>Bill payment</h2>
       <li>Pay the bills on time by getting reminders when bills are due</li>

  </body>
</html>