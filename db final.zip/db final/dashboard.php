
<?php
session_start();
$username=$_SESSION['username'];
//echo $username;
if(!isset($_SESSION['username']))
{
	header('location:login.php');
}

?>

<HTML>

<center>you are logged in!
<form><input type="button" value="Click here to proceed" onClick="window.location.href='menu.php?username=$username'"></form></center>

</HTML>