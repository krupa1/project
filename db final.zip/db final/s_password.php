<?php
session_start();
$username=$_SESSION['username'];
if(isset($_REQUEST['attempt']))
{
	
	$link = mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db('project');	

	$password = sha1(mysql_real_escape_string($_POST['$password']));
	$password1 =sha1(mysql_real_escape_string($_POST['$newpwd1']));
	$password2 =sha1(mysql_real_escape_string($_POST['$newpwd2']));
	
	if($password == $password1)
	{
		echo "Enter different password";
	}
	else if($password1 != $password2)
	{
		echo "Mismatch in the passwords";
	}
	else
	{
		$query = mysql_query("UPDATE user_details SET password='$password1' WHERE username='$username'") or die(mysql_error());	
	
		session_start();
		$_SESSION['username']=$username;
		header('location:edit2.php?username=$username');
	}
}
?>
<TABLE Border = "1"  Bgcolor="LIGHTBLUE"  Width="400"  Height="100" CellPadding = "10"  CellSpacing = "2" Align="CENTER">
<CAPTION><font size="3" face="Tahoma, Geneva, sans-serif"><B>Change password</B></font></CAPTION>
<form method="post" action="s_password.php?attempt">
<tr><td>
Current password: </td><td><input type="password" name="$password"/></td></tr>
<br>
<tr><td>
New password: </td><td><input type="password" name="$newpwd1"/></td></tr>
<br>
<tr><td>
Confirm new password: </td><td><input type="password" name="$newpwd2"/>
</td></tr>

<tr>
<td colspan="0" align="center">
<input type="button" value="Cancel" onClick="window.location.href='settings.php?username=$username1'"></td>
<td>
<input type="submit"  value="Change"/></td></tr>
</form></TABLE>