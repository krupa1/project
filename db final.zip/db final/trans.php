<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<body>
<form> 
<form>
<input type="button" value="Logout" onClick="window.location.href='logout.php'"></form>
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Reminders" onClick="window.location.href='remainders1.php?username=$username'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>
</tr>
<tr>
 <head>
            
<h3 align="center"> PERSONAL TRANSACTION DETAILS</h3>
</head>
</tr>
<?php
session_start();
$username=$_SESSION['username'];
//echo $username;

$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db($username);


$sql="SELECT * FROM transactions ORDER BY date DESC";
// OREDER BY id DESC is order result by descending 
$result = mysql_query($sql);
?>






<table width="60%" border="0" align="center" cellpadding="7" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Type</strong></td>
<td width="20%" align="center" bgcolor="#F5D6F5"><strong>Category</strong></td>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Amount</strong></td>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Date</strong></td>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Description</strong></td>
</tr>

<center>
<input type="button" value="Category View" onClick="window.location.href='category.php?username=$username'">
<input type="button" value="Monthly View" onClick="window.location.href='monthly.php?username=$username'">
<input type="button" value="Yearly View" onClick="window.location.href='yearly.php?username=$username'">
<input type="button" value="Click here to add transactions" onClick="window.location.href='trans1.php?username=$username'">
</center>
<br>


<?php
while($rows = mysql_fetch_array($result,MYSQL_BOTH))
{ // Start looping table row 
?>
<tr>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['type']; ?></td>

<?php 
	$catid = $rows['categoryid'];
$query = mysql_query("SELECT details FROM categories WHERE categoryid='$catid'") or die(mysql_error());
	
	$res = mysql_fetch_assoc($query);
	$details = $res['details'];
	
	mysql_select_db($username,$link);
?>
 
<td  align="center" bgcolor="#FFFFFF"><?php echo  $details; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['amount']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['date']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['description']; ?></td>
</tr>
<?php
// Exit looping and close connection 
}
mysql_close();
?>
</table>
