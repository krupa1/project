<?php
session_start();
$username=$_SESSION['username'];
//echo $username;
if(!isset($_SESSION['username']))
{
	header('location:signup.php');
}


?>
Your account has been created successfully

<form><input type="button" value="Click here to proceed" onClick="window.location.href='menu.php?username=$username'"></form>