<?php  
if(isset($_REQUEST['attempt']))
{
	$link = mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db('project');

	$username = mysql_real_escape_string($_POST['username']);
	$password = sha1(mysql_real_escape_string($_POST['password']));
	$email = mysql_real_escape_string($_POST['email_id']);
	$mobile = mysql_real_escape_string($_POST['mobile']);
	
	$query = mysql_query("
	SELECT username FROM user_details
	WHERE username = '$username'
	") or die(mysql_error());

	$total = mysql_num_rows($query);

	if($total > 0)
	{
		echo "username already exists!! try someother username";	
	}
	else
	{ 
 		
	$query1 = mysql_query("
		INSERT INTO user_details (username,password,email_id,mobile) 		VALUES	('$username','$password','$email','$mobile')
		") or die(mysql_error());
		
	$query2 = mysql_query("CREATE DATABASE $username") or die(mysql_error());
	
	mysql_select_db($username,$link);
	
	$query3 = mysql_query("CREATE TABLE accounts(fin_inst_name VARCHAR(25),acc_no INT PRIMARY KEY,username VARCHAR(15),password VARCHAR(20))") or die(mysql_error());
	
	$query7 = mysql_query("CREATE TABLE `categories` LIKE `project`.`categories`") or die(mysql_error());
	
	$query9 = mysql_query("INSERT categories SELECT * FROM project.categories") or die(mysql_error());
	
	$query4 = mysql_query("CREATE TABLE account_details(fin_inst_name VARCHAR(25),acc_no INT,acc_type VARCHAR(10),details varchar(100),trans_type VARCHAR(10),amount INT,balance INT,date DATE,time Time)") or die(mysql_error());
	
	$query5 = mysql_query("CREATE TABLE transactions(type VARCHAR(10),categoryid INT,amount INT,date DATE,description VARCHAR(25),FOREIGN KEY (categoryid) REFERENCES categories(categoryid))") or die(mysql_error());
	 	
	$query6 = mysql_query("CREATE TABLE budget(categoryid INT,max_amt INT,spent_amt INT,FOREIGN KEY (categoryid) REFERENCES categories(categoryid))") or die(mysql_error());
	
	$query8 = mysql_query("CREATE TABLE alerts(mobile VARCHAR(20),catid INT,FOREIGN KEY (catid) REFERENCES categories(categoryid))") or die(mysql_error());
	
	$query10 = mysql_query("CREATE TABLE reminders(event VARCHAR(100),date DATE)") or die(mysql_error());
	/*$query9 = mysql_query("CREATE TRIGGER alert_trigger
	AFTER UPDATE ON budget 
	REFERENCING NEW ROW AS NewRow,
				OLD ROW AS OldRow
	FOR EACH ROW
	WHEN(NewRow.spent_amt == NewRow.max_amt)
	BEGIN ATOMIC
		INSERT INTO alerts VALUES('2233445566','1')") or die(mysql_error());*/
		
		session_start();
		$_SESSION['username']=$username;
		header('location:sample2.php?username=$username');
	}
}	
?>


<html>

<TABLE Border = "1"  Bgcolor="LIGHTBLUE"  Width="350"  Height="100" CellPadding = "5"  CellSpacing = "0" Align="CENTER">
<CAPTION><font size="4" face="Tahoma, Geneva, sans-serif"><B>Sign Up</B></font></CAPTION>
<form method="post" action="signup.php?attempt">
 
 <tr><td>Username:</td><td><input type="text" name="username" /></td></tr> 
 <tr><td>Password:</td><td><input type="password" name="password" /></td></tr> 
 <tr><td>Email id:</td><td><input type="text" name="email_id" /></td></tr> 
 <tr><td>Mobile:</td><td><input type="text" name="mobile" /></td></tr> 
 <tr><td colspan="2" align="center"><input type="submit" value="Sign Up"/></td></tr>
</form></TABLE>
</html>