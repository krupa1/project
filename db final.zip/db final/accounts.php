<?php
?>

<body>
<form> 
<form>
<input type="button" value="Logout" onClick="window.location.href='logout.php'"></form>
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Reminders" onClick="window.location.href='remainders1.php?username=$username'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>
 <?php error_reporting (E_ALL ^ E_NOTICE); ?>
<h3 align="center"> ACCOUNT TRANSACTION DETAILS</h3>
</head>
<dd><dd><dd><dd><dd><dd><dd><form>
<input type="button" value="Click here to add account details" onClick="window.location.href='accounts1.php?username=$username'">
</font>
</Form>
<?php
session_start();
$username=$_SESSION['username'];
//echo $username;

$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
?>

<?php
mysql_select_db($username);

$query4 = mysql_query("SELECT fin_inst_name FROM accounts GROUP BY fin_inst_name") or die(mysql_error());
while($res = mysql_fetch_assoc($query4))
{
	$fin = $res['fin_inst_name'];
	
	$query = mysql_query("SELECT acc_no FROM accounts WHERE fin_inst_name='$fin'") or die(mysql_error());

	$num = mysql_num_rows($query);
	$i=1;
	while($i <= $num)
	{
		$res= mysql_fetch_array($query);
		$accno=$res['acc_no'];

		mysql_select_db($username,$link);

		$query1 = mysql_query("SELECT MAX(date) FROM account_details WHERE acc_no = '$accno' AND fin_inst_name='$fin'") or die(mysql_error());
		$date1 = mysql_fetch_assoc($query1);
		$date2 = $date1['MAX(date)'];

		$query2 = mysql_query("SELECT MAX(time) FROM account_details WHERE date='$date2' AND acc_no='$accno' AND fin_inst_name='$fin'") or die(mysql_error());

		$time1 = mysql_fetch_assoc($query2);
		$time2 = $time1['MAX(time)'];

		mysql_select_db('fin_inst_db',$link);
	
		$data = mysql_query("SELECT * FROM `user_accounts` WHERE Account_no='$accno' AND CONCAT( `Date` , ' ', `Time` ) > '$date2 $time2' AND fin_inst_name ='$fin'") or die(mysql_error());
	
		$num1 = mysql_num_rows($data);
		$j = 1;
		while($j <= $num1)
		{
			$row = mysql_fetch_assoc($data);
			$acc_no = $row['Account_no'];
			$acc_type = $row['Account_type'];
			$details = $row['Details'];
			$trans_type = $row['Trans_type'];
			$amt = $row['Amount'];
			$balance = $row['Balance'];
			$date = $row['Date'];
			$time = $row['Time'];
			mysql_select_db($username,$link);
		
			$query1 = mysql_query("INSERT INTO account_details VALUES('$fin',$acc_no,'$acc_type','$details','$trans_type','$amt','$balance','$date','$time')") or die(mysql_error());
		
			$j = $j+1;
		}
		$i = $i + 1;
	}
?>
<table width="60%" border="0" align="center" cellpadding="7" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td width="12%" align="center" bgcolor="#DEFBB9"><strong>Fin_inst</strong></td>
<td width="12%" align="center" bgcolor="#DEFBB9"><strong>Account_no</strong></td>
<td width="12%" align="center" bgcolor="#DEFBB9"><strong>Account_type</strong></td>
<td width="13%" align="center" bgcolor="#DEFBB9"><strong>Details</strong></td>
<td width="13%" align="center" bgcolor="#DEFBB9"><strong>Trans_type</strong></td>
<td width="12%" align="center" bgcolor="#DEFBB9"><strong>Amount</strong></td>
<td width="12%" align="center" bgcolor="#DEFBB9"><strong>Balance</strong></td>
<td width="20%" align="center" bgcolor="#DEFBB9"><strong>Date</strong></td>
<td width="13%" align="center" bgcolor="#DEFBB9"><strong>Time</strong></td>
</tr>


<h3 align="center"><br><?php echo $fin;?></h3>
<?php
mysql_select_db($username,$link);
$query3 = mysql_query("SELECT * FROM account_details WHERE fin_inst_name='$fin' ORDER BY date DESC") or die(mysql_error());
$num2 = mysql_num_rows($query3);
//echo $num1;
$i = 1;
while($i <= 5 and $num2 >= $i) 
{  
		
	$row = mysql_fetch_assoc($query3);
	$acc_no = $row['acc_no'];
	$acc_type = $row['acc_type'];
	$details = $row['details'];
	$trans_type = $row['trans_type'];
	$amt = $row['amount'];
	$balance = $row['balance'];
	$date = $row['date'];
	$time = $row['time'];
	Print "<tr>"; 
 	Print "<td bgcolor=#FFFFFF align=center>".$fin." </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$acc_no." </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$acc_type . " </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$details . " </td>"; 
	
	Print "<td bgcolor=#FFFFFF align=center>".$trans_type . " </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$amt . " </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$balance . " </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$date . " </td>";
	
	Print "<td bgcolor=#FFFFFF align=center>".$time . " </td>";
	
	$i =$i + 1;
	} 
?>
<form>
<input type="button" value="View all" onClick="window.location.href='a_monthly.php?username=$username&fin_inst=<?php echo $fin; ?>'">
</font>
<br/>
</Form>
<?php
}
?>



</body>