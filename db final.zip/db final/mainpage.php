<html>
<style type="text/css">
body,td,th {
	font-size: medium;
}
body {
	margin-left: 100px;
	margin-right: 100px;
}
</style>
<body>

<TABLE WIDTH="1000" BORDER="0" ALIGN="CENTER">
<tr>
<td style="background-color:#99CCFF;HEIGHT=200;">
<FONT FACE ="Rockwell" SIZE="22" COLOR ="MIDNIGHTBLUE" ALIGN="TOP"> 
<CENTER><B> eWALLET  </B></CENTER></FONT>
<BR>
<FONT FACE="Lucida Calligraphy" SIZE="6" COLOR="FIREBRICK">
<CENTER>	A Personal Finance Tracker  </CENTER>
</FONT>
</td>
</tr>
</TABLE>


<TABLE WIDTH="1000" BORDER="0" ALIGN="CENTER">
<tr valign="top">
<td style="background-color:#FF99CC;width:550px;text-align:top;HEIGHT:100px;">
<FONT FACE="COMIC SANS MS" SIZE="6" COLOR="MEDIUMVIOLETRED">
<P>
<BR/>
<UL TYPE="DISC">
<b><LI><a href="about.php">About</a>    </b><br/><BR/>
<B><LI><a href="features.php">FEATURES</a>  </B><br/><BR/>
<B><LI><a href="faqt.php">FAQS</a>    </B> 
<BR/><BR/></BR> </BR>
</UL>
</P>
</FONT>
</td>

<td style="background-color:#FFCCCC;height:100px;width:500px;text-align:top;">
<FONT FACE="TAHOMA" SIZE="6" color="#0033CC">
<br/><U>UNIQUE BENEFITS</U>
<p>
<FONT face="Verdana, Geneva, sans-serif" SIZE="5" COLOR="BROWN">
-All accounts in one place<br><br>
-Montor daily transactions<br><br>
-Set and track monthly budgets<br><br>
-Alerts and reminders<br>
</FONT>
</p>
</FONT>
</td>



<td style="background-color:#FFCC99;width:500px;text-align:top;height:100px;">
<br/><br/><br/><br/>
<center><input type="button" value="Login" onClick="window.location.href='login.php'" style="font-size:120%;width:135px;"></center>

<br/>
<center><input type="button" value="Sign Up" onClick="window.location.href='signup.php'" style="font-size:120%;width:135px;"></center>

</FONT>
</TD>
</tr>
</table>


<table WIDTH="1000" BORDER="0" ALIGN="CENTER">
<tr>
<td style="background-color:#339933;text-align:center;width:1000px;">
Our Project
</td>
</tr>
</table>

</body>
</html>

