<html>
<body>
<form> 
<form>
<input type="button" value="Logout" onClick="window.location.href='logout.php'"></form>
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Reminders" onClick="window.location.href='remainders1.php?username=$username'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>
<head>
<h3 align="center">BUDGET DETAILS</h3>
</head>

<?PHP
session_start();
$username=$_SESSION['username'];
//echo $username;

	$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
	
	mysql_select_db($username);
	$query2 = mysql_query("SELECT SUM(amount),categoryid FROM transactions GROUP BY categoryid") or die(mysql_error());
	$res = mysql_num_rows($query2);
	if($res <= 0)
	{
	}
	else
	{
	$i =0;
	while($i < $res)
	{
		$result = mysql_fetch_assoc($query2);
		$spent = $result['SUM(amount)'];
		$catid = $result['categoryid'];
	$query3 = mysql_query("UPDATE budget SET spent_amt='$spent' WHERE categoryid = '$catid'") or die(mysql_error());
	$i =$i +1;
	}
	}
	
	$data = mysql_query("SELECT * FROM budget") 
 	or die(mysql_error()); 
 	
?>
<Form name="form1" Method="POST" Action="goals1.php?attempt">
<font face="Verdana, Geneva, sans-serif" color="#990000">
<center>
<input type="button" value="Click here to edit" onClick="window.location.href='goals.php?username=$username'">
</center></font>
</Form>
<table width="60%" border="0" align="center" cellpadding="7" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td width="20%" align="center" bgcolor="#FFFFD5"><strong>Category</strong></td>
<td width="15%" align="center" bgcolor="#FFFFD5"><strong>Maximum Amount</strong></td>
<td width="13%" align="center" bgcolor="#FFFFD5"><strong>Spent Amount</strong></td>
<td width="13%" align="center" bgcolor="#FFFFD5"><strong>Remaining</strong></td>
</tr>
<?php
    
    
    
 	
	while($info = mysql_fetch_array( $data )) 
 	{  
	Print "<tr>"; 
 	$catid = $info['categoryid'];
	//echo $catid;
	//mysql_select_db('project',$link);
	$query = mysql_query("SELECT details FROM categories WHERE categoryid= '$catid'") or die(mysql_error());
	$result = mysql_fetch_assoc($query);
	$res = $result['details'];
	//echo $res;
	Print "<td bgcolor=#FFFFFF>".$res . "</td>"; 
 	
	mysql_select_db($username,$link);
	Print "<td bgcolor=#FFFFFF>".$info['max_amt'] . " </td>"; 
	Print "<td bgcolor=#FFFFFF>".$info['spent_amt'] . " </td>";
	$rem = $info['max_amt']-$info['spent_amt'];
	Print "<td bgcolor=#FFFFFF>".$rem . " </td></tr>";
	if($rem <= 0)
	{
		mysql_select_db('project',$link);
		$query = mysql_query("SELECT mobile FROM user_details WHERE username='$username'") or die(mysql_error());
		$m = mysql_fetch_assoc($query);
		$mobile = $m['mobile'];
		mysql_select_db($username,$link);
		$query6 = mysql_query("SELECT * FROM alerts WHERE catid = '$catid'") or die(mysql_error());
		if(mysql_num_rows($query6) ==0)
		{
		$query1 = mysql_query("INSERT INTO alerts VALUES('$mobile',$catid)") or die(mysql_error());		}
	
	}
	if($rem > 0)
	{
		$query7 = mysql_query("SELECT * FROM alerts WHERE catid='$catid'") or die(mysql_error());
		if(mysql_num_rows($query7) > 0)
		{
				$query8 = mysql_query("DELETE FROM alerts WHERE catid='$catid'") or die(mysql_error());
		}
	}
	} 
 	
?>

</table>




<?php
 $query4 = mysql_query("SELECT catid FROM alerts") or die(mysql_error());
 if(mysql_num_rows($query4) > 0)
 {?>
<font color="#CC0000"><h3 align="center">ALERT !!!</h3></font>
<table width="60%" border="0" align="center" cellpadding="7" cellspacing="1" bgcolor="#CC0000">	

<?php	while($res1 = mysql_fetch_assoc($query4))
	{
	$cat_id = $res1['catid'];
	Print "<tr>";
	$query5 = mysql_query("SELECT details FROM categories WHERE categoryid ='$cat_id'") or die(mysql_error());
	$res2 = mysql_fetch_assoc($query5);
	Print "<td bgcolor=#FFFFFF>".$res2['details'] ." </td></tr>";
	}
 }
 ?>
</table>
</body>
</html>
		 	
	