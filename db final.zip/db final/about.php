<html>
<body>
<table width="1400" border="0">
<tr>
<td colspan="2" style="background-color:00FFCC;">
<h1>ABOUT</h1>
</td>
</tr>
<tr valign="top">
<td style="background-color:#FFD700;width:100px;text-align:top;">
<b>Menu</b><br />
<a href="E:\html prg\feature.html">FEATURES</a><br />
<a href="E:\html prg\faq.html">FAQ</a>
<br />
</td>
<td style="background-color:#EEEEEE;height:700px;width:500px;text-align:top;">
<h3>eWallet is a innovative personal expense tracker.It helps you to take smarter financial decisions.</h3>
<p>The users can track their  expenses and incomes by week,month,year as well as by categories.<br/>
This tool connects the users to the banks and financial institutions.This automatically fetches and                  categorises data everyday following the same levels of encryption security followed by banks.<br/>
Users can set reminders to get alerts when the balance drops below a specified amount which is set                  earlier.<br/>
This tool  alerts the user on pending payments.<br/>
</p>
</tr>
<tr>
<td colspan="2" style="background-color:00FFCC ;text-align:center;">
</tr>
</table>
</body>	
</html>