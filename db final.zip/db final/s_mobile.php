<?php
session_start();
$username=$_SESSION['username'];
if(isset($_REQUEST['attempt']))
{
	
	$link = mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db('project');

	$mobile = mysql_real_escape_string($_POST['mobile']);
	$query = mysql_query("UPDATE user_details SET mobile = '$mobile' WHERE username='$username'") or die(mysql_error());
	
		
		session_start();
		$_SESSION['username']=$username;
		header('location:edit4.php?username=$username');
}
?>




<TABLE Border = "1"  Bgcolor="LIGHTBLUE"  Width="400"  Height="100" CellPadding = "10"  CellSpacing = "2" Align="CENTER">
<CAPTION><font size="3" face="Tahoma, Geneva, sans-serif"><B>Change mobile number</B></font></CAPTION>
<form method="post" action="s_mobile.php?attempt">
<tr>
<td colspan="0">
Mobile number</td><td><input type="text" name="emailid"/>
<br><br>
</td></tr>

<tr>
<td colspan="0" align="center">
<input type="button" value="Cancel" onClick="window.location.href='settings.php?username=$username1'"></td>
<td><input type="submit"  value="Change"/></td></tr>
</form></TABLE>