<html>
<p style="color:blue;font-size:40px;">FREQUENTLY ASKED QUESTIONS</p>
 <li><a href="#01">What can I do with Money Manager?</a></li>                    
<li><a href="#02">What's the key benefit of Money Manager?</a></li>                 
<li><a href="#03">Which browsers does Money Manager support?</a></li>                
<h3 id="01">1. What can I do with Money Manager?</h4>                
<p >Money Manager is for you if you are just starting out on your financial journey. Or, maybe you've been on your financial journey for awhile, and you're finally ready to pay more attention. Keep track of your everyday expenses and take control of your personal finance.Using ewallet you can easily keep track of your everyday expenses and keep an eye on your cash flow. No more overdrafts!
</p>            
<h4>What do I get with Money Manager?</h4>
<li><strong>track your critical financial information</strong> spanning assests and liabilities</li>
 <li><strong>A predictable financial future.</strong> You can view everyday your savings account balance after allowing for each bill to be paid, all the way to your next salary and beyond.</li>                  <li><strong>Alerts</strong> about balances, transactions, and bill reminders automatically <strong>delivered to your mobile phone or email.</strong></li>                  	
<li><strong>Monthly budget goals</strong> for any or all of your categories.</li>                  	<li><strong>Charts</strong> so you can understand your spending habits. For example, you can see how much you've spent during your trip no matter which account you have used for it</li>               
<li><strong>Your spending automatically assigned to standard categories or to new categories you dream up.</strong>  so you'll have fewer and fewer adjustments to make as time goes by.</li>         <li>An easy method to record and keep track of what you buy with your cash.</li>                    <li><strong>Your choice of Windows and Macintosh browsers</strong> including Internet Explorer, Safari, and Firefox.</li>                  	
<h4>What doesn't Money Manager do?</h4>              	<li><strong>Import transactions -</strong> When you add your bank accounts, we gather up to 90 days worth of your previous transactions from those accounts. You can't import any transactions previous to that date, and you can't enter them manually either. We will continue to download and keep your transactions as long as you maintain your subscription to Money Manager.</li>               
 <li><strong>Subcategories -</strong> Some people really want to track things like Auto (Fuel), Auto (Repair), and Auto (Wash) as separate categories so that they can see those totals either separately or rolled up into the master category name (Auto). Again, this is a level of detail that Money Manager doesn't track. Our purpose is to give you a tool that is a convenient introduction to finance that helps save time and money.</li>        <li><strong>Paying bills or transferring money -</strong> You can't use Money Manager to transmit funds from one place to another.</li>                   
<li><strong>Writing cheques -</strong> You can't use Money Manager to write or print cheques. However, you can enter cheques you've written to see how they'll affect your balance once they clear.</li>                	<li><strong>Reconciling -</strong> Reconciling is useful for matching up your paper chequebook register with the transactions on your bank statement. With Money Manager, you're seeing the bank transactions right on the screen. To match up your receipts with the bank transactions, you can make an entry in the Note field for each transaction as you check it off as valid.</li>               
<h4>Which browser should I use?</h4>              	
<p>You can use any of the <a href="#03">browsers that we support.</p>              	
 <p ><a href="#">back to top</a></p>                              	
<h3 id="02">2. What's the key benefit of Money Manager?</h3>                
<p>Money Manager helps you be on top of your finances. Read on to learn how.</p>       
<h4>see how your time is saved and view your spending trends</h4>       	 
<p>A single view of  your accounts  which saves time and gain a sense of control without having to log into multiple website .</p>                
<p> A real time information of your spendswhich further enables you to map the spending trends and categorize them</p>                
<h4>See how your bills affect your balance</h4>                
<p>This insight into your bills isn't restricted to just your Home page account. Each reminder is linked to the account from which you pay the bill.</p>                
<h4>Always know where you stand!</h4>              	
<p>We have new alerts and reports to keep you in touch with your money. For instance, we can let you know when your savings account balance dips below an amount you set. Or, we can tell you if a large expense goes through in any of your accounts. There are lots of choices.</p>              	
<p>To set up your email alerts, click the <strong>Settings</strong> link in the banner and then click the <strong>Alerts &amp; Notifications</strong> tab.</p>               
 <h4>Relax and find things easily</h4>                
<p>With Money Manager, you can relax and find things easily.</p>                
<p>Do assign categories to your transactions. Categories help you know where your money comes from and where it goes. For an uncategorised transaction, you'll see <strong>Choose a category</strong> under <strong>Categories</strong> - just to remind you to assign categories to all your transactions. Once you start categorising, we'll learn how you categorise and automatically follow the pattern for your other transactions. Then your <strong>Trends</strong> and <strong>Goals</strong> pages will be much more accurate.</p>           	 <p><a href="#">back to top</a></p>                                
<h3 id="03">3. Which browsers does Money Manager support?</h3>                <p>Money Manager supports the following browsers on the Microsoft Windows operating system:</p>                              	
<li>Internet Explorer 6, 7, and 8</li>                    
<li>Firefox 2 and 3</li>                   
 <li>Safari 3</li>                   
 <p><a href="#">back to top</a></p>                      
</html>