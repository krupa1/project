<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<body>
<form> 
<form>
<input type="button" value="Logout" onClick="window.location.href='logout.php'"></form>
<TABLE Border = "1"  Bgcolor="CORNFLOWERBLUE" CellPadding = "0"  CellSpacing = "0" bordercolor="#FFFFFF" Align="center">
 <tr>
 <td width="97" bgcolor="#DEFBB9"><center><input type="button" value="Accounts" onClick="window.location.href='accounts.php?username=$username'" style="background-color:#DEFBB9;font-size:120%;width:135px;"></center></td>
 <td width="129" bgcolor="#F5D6F5"><center><input type="button" value="Transactions" onClick="window.location.href='trans.php?username=$username'" style="background-color:#F5D6F5;font-size:120%;width:135px;"></center></td>
<td width="75" bgcolor="#FFFFD5"><center><input type="button" value="Goals" onClick="window.location.href='goals1.php?username=$username'" style="background-color:#FFFFD5;font-size:120%;width:135px;"></center></td>
 <td width="113" bgcolor="#C1DAEA"><center><input type="button" value="Reminders" onClick="window.location.href='remainders1.php?username=$username'" style="background-color:#C1DAEA;font-size:120%;width:135px;"></center></td>
 <td width="88" bgcolor="#F8DCDF"><center><input type="button" value="Settings" onClick="window.location.href='settings.php?username=$username'" style="background-color:#F8DCDF;font-size:120%;width:135px;"></center></td></tr> 
 </table>
 </form>
</tr>
<tr>
 <head>
            
<h3 align="center"> PERSONAL TRANSACTION DETAILS</h3>
</head>
</tr>
<?php
session_start();
$username=$_SESSION['username'];
//echo $username;

$link=mysql_connect('localhost','root','mysql') or die('cant connect to database');
	mysql_select_db($username);


//$sql="SELECT * FROM transactions ORDER BY date DESC";
// OREDER BY id DESC is order result by descending 
//$result = mysql_query($sql);
?>
<dd><dd><dd><dd><dd><dd><dd>
<input type="button" value="Category View" onClick="window.location.href='category.php?username=$username'">
<input type="button" value="Yearly View" onClick="window.location.href='yearly.php?username=$username'">
<input type="button" value="Click here to add transactions" onClick="window.location.href='trans1.php?username=$username'">
<br/>
</br>
<?php 
/*$date = $result['date'];
$query=mysql_query("SELECT YEAR('$date') as 'Year'");
$res1= mysql_fetch_assoc($query);
$yy = $res1['Year'];
echo $yy;
*/?>
<?php
	$query2 = mysql_query("SELECT MIN(date) FROM transactions") or die(mysql_error());
	$res1 = mysql_fetch_assoc($query2);
	$last = $res1['MIN(date)'];
	//echo $last;
	$query3= mysql_query("SELECT YEAR('$last') as 'Year'") or die(mysql_error());
	$res1= mysql_fetch_assoc($query3);
	$lyy = $res1['Year'];
	//echo $lyy;
	$date = time();
	$yy = date('Y', $date);
	
	//$date = time();
	$mm = date('m', $date);
	$m = date('M',$date);
	//echo $mm;
	
	/*$query4= mysql_query("SELECT * FROM transactions GROUP BY MONTH(date)") or die(mysql_error());
	$rows = mysql_num_rows($query4);
	$i = 1;
	while($i <= $rows)*/
	while($yy >= $lyy)
	{
	
	while($mm > 0)
	{
		$query1 = mysql_query("SELECT * FROM transactions WHERE MONTH(date) = '$mm' AND YEAR(date)='$yy'");
	if(mysql_num_rows($query1) > 0)
	{	
		?>
<table width="60%" border="0" align="center" cellpadding="7" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Type</strong></td>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Category</strong></td>
<td width="20%" align="center" bgcolor="#F5D6F5">
<strong>Amount</strong></td>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Date</strong></td>
<td width="13%" align="center" bgcolor="#F5D6F5"><strong>Description</strong></td>
</tr>
<br>
<?php switch($mm)
	{
		case '1': $mon='Jan'; break;
		case '2': $mon='Feb'; break;
		case '3': $mon='Mar'; break;
		case '4': $mon='Apr'; break;
		case '5': $mon='May'; break;
		case '6': $mon='Jun'; break;
		case '7': $mon='Jul'; break;
		case '8': $mon='Aug'; break;
		case '9': $mon='Sep'; break;
		case '10': $mon='Oct'; break;
		case '11': $mon='Nov'; break;
		case '12': $mon='Dec'; break;
	}	?>
<head>
<h4 align="left"><?php echo $mon;echo " ";echo $yy?></h4>
</head>
    
<?php
	while($res = mysql_fetch_assoc($query1))
	{
	/*echo $res['type'];
	echo $res['categoryid'];
	echo $res['amount'];
	echo $res['date'];*/?>
<tr>
<td align="center" bgcolor="#FFFFFF"><?php echo $res['type']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $res['categoryid']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $res['amount']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $res['date']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $res['description']; ?></td>
</tr>
<?php	
	}
	}
	$mm =$mm-1;
	
	}
	$mm = 12;
	$yy =$yy-1;
	}
?>